import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  test: {
    include: ['src/game/tests/**/*.test.ts', 'server/tests/**/*.test.ts'],
  },
})
